package Model

class Administrador(
    id : Int,
    nombre : String,
    var clave : String
) : Persona(id,nombre) {

    override fun toString(): String {
        super.toString()
        return "Administrador(clave='$clave')"
    }
}