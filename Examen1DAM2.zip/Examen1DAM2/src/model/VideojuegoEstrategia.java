package model;

public class VideojuegoEstrategia extends VideoJuego {

    int complejidad,duracionPartida;

    public VideojuegoEstrategia() {
    }

    public VideojuegoEstrategia(String titulo, String developer, String ageRating, int relaseYear, double price, int complejidad, int duracionPartida) {
        super(titulo, developer, ageRating, relaseYear, price);
        this.complejidad = complejidad;
        this.duracionPartida = duracionPartida;
    }

    //повинен додавати 3% до ціни для кожного рівня складності.
    //debe añadir un 3% al precio por cada nivel de complejidad
    public void calculatePrice(){

        double price = super.getPrice();
        if (complejidad > 0){
            price += (((price * 3)/100) * complejidad);
            super.setPrice(price);
            System.out.printf("Precio por videojuegoEstrategia con complejidad %n era %f.2",complejidad,price);
        }else System.out.printf("Precio por videojuegoEstrategia con complejidad %n era %f.2",complejidad,super.getPrice());
    }

    public int getComplejidad() {
        return complejidad;
    }

    public void setComplejidad(int complejidad) {
        this.complejidad = complejidad;
    }

    public int getDuracionPartida() {
        return duracionPartida;
    }

    public void setDuracionPartida(int duracionPartida) {
        this.duracionPartida = duracionPartida;
    }
}
