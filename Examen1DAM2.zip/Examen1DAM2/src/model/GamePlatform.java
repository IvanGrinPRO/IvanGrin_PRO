package model;

import java.util.ArrayList;

public class GamePlatform {

    ArrayList<VideoJuego> videoJuegos = new ArrayList<>();

    public GamePlatform() {
    }

    public GamePlatform(ArrayList<VideoJuego> videoJuegos) {
        this.videoJuegos = videoJuegos;
    }

    public void addGame(VideoJuego videoJuego){

        videoJuegos.add(videoJuego);

    }

    public void removeGame(VideoJuego videoJuego){

        videoJuegos.remove(videoJuego);

    }

    public void mostrarJuegos(){

        for (VideoJuego videoJuego : videoJuegos){
            System.out.println(videoJuego);

        }
    }

    public void mostrarJuegoPorPrecio(){
        ArrayList<VideoJuego> videoJuegos1 = new ArrayList<>();
        for (int i = 0; i < videoJuegos.size(); i++) {


        }

    }


    public double totalPrice(){
        double price = 0;
        for (int i = 0; i < videoJuegos.size(); i++) {
            price = videoJuegos.get(i).getPrice();
        }

        return price;
    }

    public void mostraPorAge(){



    }

    public ArrayList<VideoJuego> getVideoJuegos() {
        return videoJuegos;
    }

    public void setVideoJuegos(ArrayList<VideoJuego> videoJuegos) {
        this.videoJuegos = videoJuegos;
    }
}
