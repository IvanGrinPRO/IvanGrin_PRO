package Model

enum class Posicion {
    Portero,Defensor,Mediocentro,Delantero

}