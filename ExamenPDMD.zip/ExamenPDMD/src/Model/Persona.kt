package Model

abstract class Persona(
    var id : Int,
    var nombre : String
) {
    override fun toString(): String {
        return "Persona(id=$id, nombre='$nombre')"
    }
}