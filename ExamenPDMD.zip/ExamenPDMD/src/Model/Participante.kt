package Model

class Participante(

    id : Int,
    nombre : String,
    var puntos : Int,
    var plantilla : MutableList<Jugador>
) : Persona(id,nombre) {

    var jugadores : MutableList<Jugador> = mutableListOf()

    init {
        plantilla = mutableListOf()
    }

    fun addJugador(jugador: Jugador) {
        var temp = estaJugador(jugador.id)
        if (temp !=null || jugador.valor > 10000000){
            println("no se puede adminir este jugador")
        }else {
            jugadores.add(jugador)
            println("Jugador con ${jugador.id} admitido en exito")
        }
    }

    fun estaJugador(id : Int){
        jugadores.filter { return@filter it.id == id }

    }

    fun mostrarDatosJugadores(){

        jugadores.forEach({item -> item.toString()})

    }

    override fun toString(): String {
        super.toString()
        return "Participante(puntos=$puntos, plantilla=$plantilla)"
    }
}