package model;

public class VideoJuego {

    String titulo,developer,ageRating;
    int relaseYear;
    double price;

    public VideoJuego() {
    }


    public VideoJuego(String titulo, String developer, String ageRating, int relaseYear, double price) {
        this.titulo = titulo;
        this.developer = developer;
        this.ageRating = ageRating;
        this.relaseYear = relaseYear;
        this.price = price;
    }

    @Override
    public String toString() {
        return "VIdeoJuegos{" +
                "titulo='" + titulo + '\'' +
                ", developer='" + developer + '\'' +
                ", ageRating='" + ageRating + '\'' +
                ", relaseYear=" + relaseYear +
                ", price=" + price +
                '}';
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDeveloper() {
        return developer;
    }

    public void setDeveloper(String developer) {
        this.developer = developer;
    }

    public String getAgeRating() {
        return ageRating;
    }

    public void setAgeRating(String ageRating) {
        this.ageRating = ageRating;
    }

    public int getRelaseYear() {
        return relaseYear;
    }

    public void setRelaseYear(int relaseYear) {
        this.relaseYear = relaseYear;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
