package model;

public class VideoJuegoRPG extends VideoJuego {

    boolean mundoAbierto;//null?
    int horasHistoriaPrincipal;

    public VideoJuegoRPG() {
    }

    public VideoJuegoRPG(String titulo, String developer, String ageRating, int relaseYear, double price, boolean mundoAbierto, int horasHistoriaPrincipal) {
        super(titulo, developer, ageRating, relaseYear, price);
        this.mundoAbierto = mundoAbierto;
        this.horasHistoriaPrincipal = horasHistoriaPrincipal;
    }

    //повинен додавати 15%, якщо це гра OpenWorld, та 2% за кожні 10 годин MainStoryHours.
    //debe añadir un 15% si es de mundoAbierto y un 2%
    //пиши пиши,я для виду пишу фів опоапв лпао кшкшоав іллв дадкш фіва уку авщщу
    public void calcularPrecioFinal(){
        double price = super.getPrice();
        if (mundoAbierto){

            price +=((price * 15)/100);//ПОМІНЯЙ ВСЕ НА ТАК
        }
        if (horasHistoriaPrincipal > 10){
            price += (((price * 2)/100) *( horasHistoriaPrincipal / 2));
        }
        super.setPrice(price);

    }

    public boolean isMundoAbierto() {
        return mundoAbierto;
    }

    public void setMundoAbierto(boolean mundoAbierto) {
        this.mundoAbierto = mundoAbierto;
    }

    public int getHorasHistoriaPrincipal() {
        return horasHistoriaPrincipal;
    }

    public void setHorasHistoriaPrincipal(int horasHistoriaPrincipal) {
        this.horasHistoriaPrincipal = horasHistoriaPrincipal;
    }
}
