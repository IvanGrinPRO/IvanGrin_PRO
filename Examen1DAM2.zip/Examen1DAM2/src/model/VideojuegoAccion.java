package model;

public class VideojuegoAccion extends VideoJuego {

    int violeceLevel;
    boolean multiplayerMode;

    public VideojuegoAccion() {
    }

    public VideojuegoAccion(String titulo, String developer, String ageRating, int relaseYear, double price, int violeceLevel, boolean multiplayerMode) {
        super(titulo, developer, ageRating, relaseYear, price);
        this.violeceLevel = violeceLevel;
        this.multiplayerMode = multiplayerMode;
    }


    //повинен додати 5% до базової ціни, якщо ViolenceLevel > 3, та ще 10%, якщо є багатокористувацький режим.
    //debe añadir un 5% al precio base si nivelViolencia > 3 y otro 10% si tiene modoMultijugador
    public void calculatePrice(){
        double price  = super.getPrice();
    if (violeceLevel > 3 && multiplayerMode){
            price += (price * 30)/100;
            super.setPrice(price);//30%
        System.out.println("El precio era " + price);
            return;
    } else if (violeceLevel > 3) {
        price += (price * 5)/100;
        super.setPrice(price);//5%
        System.out.println("El precio era " + price);
        return;
    } else if (multiplayerMode) {
        price += (price * 10)/ 100;
        super.setPrice(price);//10%
        System.out.println("El precio era " + price);
        return;
    }

    }

    public int getVioleceLevel() {
        return violeceLevel;
    }

    public void setVioleceLevel(int violeceLevel) {
        this.violeceLevel = violeceLevel;
    }

    public boolean isMultiplayerMode() {
        return multiplayerMode;
    }

    public void setMultiplayerMode(boolean multiplayerMode) {
        this.multiplayerMode = multiplayerMode;
    }


}
