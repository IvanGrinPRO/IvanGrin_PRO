package Controll

import Model.Administrador
import Model.Jugador
import Model.Posicion

class Fantasy (
    var administrador: Administrador

) {
    var portrero: Int = 0;
    var defensor: Int = 0
    var mediocentro: Int = 0
    var delantero: Int = 0

    fun verificarJugadores(jugadores: MutableList<Jugador>): Boolean {

        jugadores.forEach({ it ->
            if (it.posicion == Posicion.Portero) {
                portrero++
            }
            if (it.posicion == Posicion.Defensor) {
                defensor++
            }
            if (it.posicion == Posicion.Mediocentro) {
                mediocentro++
            }
            if (it.posicion == Posicion.Delantero) {
                delantero++
            }
        })
        if (portrero != 1 || defensor != 2 || mediocentro != 2 || delantero != 1) {

            return false
        } else return true
    }

    fun iniciarJuego(clave : String, jugadores: MutableList<Jugador>, jugadores2: MutableList<Jugador>){
        val equipo1 : Boolean = verificarJugadores(jugadores)
        val equipo2 : Boolean = verificarJugadores(jugadores2)
        if (administrador.clave != clave){
            println("Clave no esta correcto")
        }else{
            if (!equipo1 || !equipo2){

                println("equipos no estan completados")
            }

        }

    }


    fun juego(jugadores1: MutableList<Jugador>, jugadores2: MutableList<Jugador>){

        val puntos1 : Int
        val puntos2 : Int

        jugadores1.forEach({})
    }
}
