package Model

class Jugador(
    id : Int,
    nombre : String,
    var posicion: Posicion,
    var valor : Int = 10000000

) : Persona(id,nombre) {

    override fun toString(): String {
        super.toString()
        return "Jugadores(posicion=$posicion, valor=$valor)"
    }
}